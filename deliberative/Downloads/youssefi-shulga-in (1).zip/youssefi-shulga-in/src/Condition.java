/**
 * 23.09.19.
 *
 * @Autor
 * @Autor Dahn Youssefi (268785)
 */
public interface Condition {
    boolean apply(int x, int y);
}
